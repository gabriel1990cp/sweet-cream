=== DiamondTheme Tools ===

Plugin Name: DiamondTheme Tools
Plugin URI: http://we-biz.biz/wp/
Description: Plugin consists of shortcodes. It also has custom post types - Portfolio, Testimonials, Team, Service, Pricing and Contact Block.
Author: DiamondTheme
Author URI: http://themeforest.net/user/diamondtheme
Version: 1.0
License: GNU General Public License version 3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

This plugin is used to enable shortcodes in the theme. It is also used to enable custom post types - Portfolio, Testimonials, Team, Service, Pricing and Contact Block.
